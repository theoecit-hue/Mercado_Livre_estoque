const U = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const T = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
const KEY = 'vitrine:itens';

async function cmd(args) {
  if (!U || !T) throw new Error('Banco de dados (Upstash) nao configurado');
  const r = await fetch(U, { method: 'POST', headers: { Authorization: 'Bearer ' + T, 'Content-Type': 'application/json' }, body: JSON.stringify(args) });
  const j = await r.json();
  if (j.error) throw new Error(j.error);
  return j.result;
}
exports.load = async () => { const v = await cmd(['GET', KEY]); try { return v ? JSON.parse(v) : []; } catch (e) { return []; } };
exports.save = (items) => cmd(['SET', KEY, JSON.stringify(items)]);
